#include <bits/stdc++.h>
using namespace std;
using ll = long long;
int main () {
	ios::sync_with_stdio(0), cin.tie(0);
	string s;
	cin >> s;
	int n = s.size();
	vector<int> L;
	ll sum = 0;
	vector<pair<ll, int>> res;
	for(int i = 0; i < n; i ++) {
		if(s[i] == '\\') {
			L.push_back(i);
		} else if(s[i] == '/' && L.size()) {
			int l = L.back(), r = i;
			L.pop_back();
			ll add = r - l;
			while(res.size() && res.back().second > l) {
				add += res.back().first;
				res.pop_back();
			}
			res.push_back({add, l});
		}
	}
	for(int i = 0; i < res.size(); i ++) {
		sum += res[i].first;
	}
	cout << sum << '\n';
	cout << res.size() << ' ';
	for(int i = 0; i < res.size(); i ++) {
		cout << res[i].first << ' ';
	}
	cout << "\n";
}