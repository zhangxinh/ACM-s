#include<bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n;
    cin >> n;
    vector<vector<int>> G(n);
    vector<int> deg(n);
    for(int i = 0; i < n; i ++) {
        int m;
        cin >> m;
        while(m --) {
            int v;
            cin >> v;
            v --;
            G[v].push_back(i);
            deg[i] ++;
        }
    }
    vector<int> dp(n);
    queue<int> q;
    for(int i = 0; i < n; i ++) {
        if(!deg[i]) {
            q.push(i);
            dp[i] = 1;
        }
    }
    while(q.size()) {
        int u = q.front();
        q.pop();
        for(int v : G[u]) {
            if(! -- deg[v]) {
                q.push(v);
            }
            if(v < u) {
                dp[v] = max(dp[v], dp[u] + 1);
            } else {
                dp[v] = max(dp[v], dp[u]);
            }
        }
    }
    int res = 0;
    for(int i = 0; i < n; i ++) {
        if(deg[i]) {
            res = -1;
            break;
        }
        res = max(res, dp[i]);
    }
    cout << res << '\n';
}