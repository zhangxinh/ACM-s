#include <bits/stdc++.h>
using namespace std;
using ll = long long;
struct Mint {
    const int mod = 998244353;
    ll v;
    Mint() {}
    Mint(ll v) : v(v) {
        if(v < 0) v += mod;
    }
    friend ostream& operator<<(ostream& os, const Mint& v) { return os << v.v; }
    friend istream& operator>>(istream& is, Mint& v) { return is >> v.v; }
    Mint& operator+=(const Mint& a) {
        (v += a.v) %= mod;
        return *this;
    }
    Mint& operator*=(const Mint& a) {
        v = (v * a.v) % mod;
        return *this;
    }
    Mint operator+(const Mint& p) const { return Mint(*this) += p; }
    Mint operator*(const Mint& k) const { return Mint(*this) *= k; }
};
int main () {
    Mint inv_24 = 291154603;
    int _ = 1;
    cin >> _;
    while(_ --) {
        Mint n;
        cin >> n;
        Mint res = (n * n * n * n + Mint(-6) * n * n * n + Mint(23) * n * n + Mint(-18) * n + Mint(24)) * inv_24;
        cout << res << '\n';
    }
}