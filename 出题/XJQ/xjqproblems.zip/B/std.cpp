#include<bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n;
    cin >> n;
    vector<int> a(n);
    for(int i = 0; i < n; i ++) {
        cin >> a[i];
    }
    int val = 1;
    bool res = false;
    for(int i = 0; i < n; i ++) {
        val *= 3;
    }
    for(int i = 1; i < val; i ++) {
        int sum = 0;
        int x = i;
        for(int c = 0; c < n; c ++) {
            if(x % 3 == 1) sum += a[c];
            if(x % 3 == 2) sum -= a[c];
            x /= 3;
        }
        if(!sum) {
            res = true;
            break;
        }
    }
    cout << (res ? "Yes" : "No") << '\n';
}