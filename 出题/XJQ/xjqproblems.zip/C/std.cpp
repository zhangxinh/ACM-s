#include <bits/stdc++.h>
using namespace std;

namespace Dinic {
    using ll = long long;
    const int MAX_V = 500;
    const ll INF = 1e12;
    struct Edge {
        int from, to;
        ll  cup, flow;
        Edge(int u, int v, int c, int f) : from(u), to(v), cup(c), flow(f) {}
    };
    struct Graph {

        int s, t, n, m;
        vector<Edge> es;
        vector<int> G[MAX_V];
        int level[MAX_V], iter[MAX_V];
        bool vis[MAX_V];

        Graph(int s, int t, int n = MAX_V) : n(n), s(s), t(t) {
            es.clear();
            for(int i = 0; i < n; i ++) {
                G[i].clear();
            }
        };

        void addEdge(int u, int v, int c) {
            es.push_back({u, v, c, 0}), es.push_back({v, u, 0, 0});
            m = es.size();
            G[u].push_back(m - 2), G[v].push_back(m - 1);
        }

        ll dfs(int v, ll f) {
            if(v == t || f == 0) return f;
            ll flow = 0, d;
            for(int &i = iter[v]; i < G[v].size(); i ++) {
                auto &e = es[G[v][i]], &reve = es[G[v][i] ^ 1];
                if(level[v] + 1 == level[e.to] && (d = dfs(e.to, min(f, e.cup - e.flow))) > 0) {
                    e.flow += d, reve.flow -= d;
                    flow += d;
                    f -= d;
                    if(! f) break;
                }
            }
            return flow;
        }

        bool bfs() {
            memset(vis, false, sizeof vis);
            queue<int> q;
            q.push(s);
            level[s] = 0;
            vis[s] = true;
            while(q.size()) {
                int v = q.front();
                q.pop();
                for(int i = 0; i < G[v].size(); i ++) {
                    auto &e = es[G[v][i]], &reve = es[G[v][i] ^ 1];
                    if(!vis[e.to] && e.cup > e.flow) {
                        vis[e.to] = true;
                        level[e.to] = level[v] + 1;
                        q.push(e.to);
                    }
                }
            }
            return vis[t];
        }

        ll maxflow() {
            ll flow = 0;
            while(bfs()) {
                memset(iter, 0, sizeof iter);
                flow += dfs(s, INF);
            }
            return flow;
        }

    };
};
using namespace Dinic;

int main () {
    ios::sync_with_stdio(0), cin.tie(0);
    int n;
    cin >> n;
    vector<int> odd, even, a(n);
    for(int i = 0; i < n; i ++) {
        cin >> a[i];
        if(a[i] & 1) odd.push_back(i);
        else even.push_back(i);
    }
    if(odd.size() != even.size()) {
        cout << "No\n";
        return 0;
    }
    Graph gra(n, n + 1, n + 2);
    for(int i : odd) {
        gra.addEdge(n, i, 2);
    }
    for(int i : even) {
        gra.addEdge(i, n + 1, 2);
    }
    auto isprime = [&](int x) {
        bool res = true;
        for(int i = 2; i <= x / i; i ++) {
            if(x % i == 0) {
                res = false;
                break;
            }
        }
        return res;
    };
    for(int i : odd) {
        for(int j : even) {
            if(isprime(a[i] + a[j])) {
                gra.addEdge(i, j, 1);
            }
        }
    }
    cout << (gra.maxflow() == n ? "Yes" : "No") << '\n';
}